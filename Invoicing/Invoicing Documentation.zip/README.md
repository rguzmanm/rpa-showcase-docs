# Instructions
1. Read the attached Process Definition Document to understand the process before automation.

2. Design an automation solution, considering potential process improvements, and document it using the provided Solution Design Document template (feel free to use any other document you find useful).

3. Build your solution using the RPA tool of your preference.

4. Test your solution

## Additional considerations

* Be aware that unexpected (not documented) exceptions might be present on the RPA Showcase page.

Have fun!